package controller;

/**
 * This class is of one of the obstacle type that is Teleportation
 * <p>
 * Teleportation class has 2 array variables x and y. Since Teleportation obstacles need to be in many numbers so that we can set them in the board, array x is going
 * to have the x coordinates of the obstacles and array y will have the y coordinates of the obstacles
 * </p>
 * @author shailab
 */
public class Teleportation {
    /**
     * An array of X coordinates.
     */
    private static int[] x;
    /**
     * An array of Y coordinates.
     */
    private static int[] y ;

    /**
     * Empty constructor
     */
    public Teleportation() {
    }
    /**
     * Set X coordinates of Teleportation Obstacles
     * @param x an Array of x coordinates
     */
    public static void setX(int[] x) {
        Teleportation.x = x;
    }

    /**
     * Set Y coordinates of Teleportation Obstacles
     * @param y an Array of Y coordinates
     */
    public static void setY(int[] y) {
        Teleportation.y = y;
    }
    /**
     * This method will help to set the obstacles in the board and also check if this certain obstacles will be encountered or not when player is moving.
     * @param m x coordinate of blocks of board
     * @param n y coordinate of blocks of board
     * @return True if the coordinates of the blocks of the board equals coordinates of obstacle.
     */
    public  boolean checkTeleportation(int m, int n){
        for (int a =0; a<x.length;a++) {
            int b=0;
            do{
                if (m==x[a] && n==y[a]) {
                    return true;
                }else
                    b++;
            }while (b< y.length);
        }
        return false;
    }
}
