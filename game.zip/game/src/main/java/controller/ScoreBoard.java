//package controller;
//
//public class ScoreBoard {
////    public String playerName;
////    public int numberOfTimesWon;
////
////    public ScoreBoard(String playerName, int numberOfTimesWon) {
////        this.playerName = playerName;
////        this.numberOfTimesWon = numberOfTimesWon;
////    }
////
////    public String getPlayerName() {
////        return playerName;
////    }
////
////    public void setPlayerName(String playerName) {
////        this.playerName = playerName;
////    }
////
////    public int getNumberOfTimesWon() {
////        return numberOfTimesWon;
////    }
////
////    public void setNumberOfTimesWon(int numberOfTimesWon) {
////        this.numberOfTimesWon = numberOfTimesWon;
////    }
////
////}
