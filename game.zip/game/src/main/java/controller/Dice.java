package controller;

import java.util.Random;

/**
 * This class is to roll two dices inorder to know the moves and the direction when playing the game.
 *
 * @author shailab
 */
public class Dice {

    /**
     * Rolling dice and moving the player to square
     * This method will calculate move number when playing the game
     * @return integer with which we will move player.
     */
    public static Integer moveTo() {
        Random random = new Random();
        int dice1 = 0;
        do {
            dice1 = random.nextInt(5);
        } while (dice1 == 0);
        return dice1;
    }

    /**
     * Rolling dice and moving the player in specific direction
     * This method will calculate in which direction player should move
     * @return String with which we will move player in the particular direction.
     */
    public static String direction() {
        Random random = new Random();
        int dice2 = 0;
        do {
            dice2 = random.nextInt(5);
        } while (dice2 == 0);
        if(dice2==1){
            return "forward";
        }else if(dice2==3){
            return "forward2";
        }else if(dice2==2){
            return"backward";
        }else
            return "miss";
    }


}