package controller;
/**
 * This class is of player which is basically contains identity of player like players name and players position in the board
 * <p>
 * Player class has 3 variables x, y (x, y are thr player coordinates), player name.
 * </p>
 * @author shailab
 */
public class Player {
    /**
     * Player Name
     */
    private String playerName;

    /**
     * X coordinate of player.
     */
    private int x;
    /**
     * Y coordinate of player.
     */
    private  int y;
    /**
     * variable declared inorder to make player miss their turn
     */
    public boolean skipTurn;

    /**
     * Getting player name
     * @return Player name
     */
    public String getPlayerName() {
        return playerName;
    }
    /**
     * Set player name
     * @param playerName Name of the player
     */
    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }
    /**
     * Getting x coordinate of player
     * @return Player X coordinate
     */
    public int getX() {
        return x;
    }

    /**
     * Set X coordinate of player
     * @param x x coordinate of player
     */
    public void setX(int x) {
        this.x = x;
    }
    /**
     * Set Y coordinate of player
     * @param y y coordinate of player
     */
    public void setY(int y) {
        this.y = y;
    }
    /**
     * Constructor
     * @param x x coordinate of player
     * @param y y coordinate of player
     */
    public Player(int x, int y) {
        this.x = x;
        this.y = y;
    }
    /**
     * Getting Y coordinate of player
     * @return Player Y coordinate
     */
    public int getY() {
        return y;
    }
    /**
     * This method used to check weather the player positions are equal or not. It is used to avoid player clashing with each other while playing the game.
     * @param p player object
     * @return True if both player position are equals otherwise false.
     */
    public boolean equals(Player p){
            return x == p.getX() && y == p.getY();
    }

}

