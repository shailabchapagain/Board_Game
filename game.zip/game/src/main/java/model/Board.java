package model;

import controller.Player;
import static model.Game.*;

/**
 * This class will generate the board with user defined rows and columns.Also, player's initial position(user-defined) and random obstacles are set on the board.
 * @author shailab
 */
public class Board {
    /**
     *  Rows of board.
     */
    public static int rows;
    /**
     *  Column of board.
     */
    public static int columns;

    /**
     * This method will check if the user defined inputs for rows and columns are string or number
     * @param s input given by user
     * @return true if input is number otherwise false
     */
    static boolean isNumber(String s)
    {
        for (int i = 0; i < s.length(); i++)
            if (!Character.isDigit(s.charAt(i)))
                return false;
        return true;
    }

    /**
     * Set rows of board
     * @param rows integer number to create rows of board
     */
    public void setRows(int rows) {
        Board.rows = rows;
        if (rows <= 0 || !isNumber(String.valueOf(rows)) ) {
            throw new IllegalArgumentException();
        }
    }
    /**
     * Get columns of board
     * @return columns number of board
     */
    public int getColumns() {
        return columns;
    }
    /**
     * Set columns of board
     * @param columns integer number to create columns of board
     */
    public void setColumns(int columns) {
        Board.columns = columns;
        if (columns <= 0 || !isNumber(String.valueOf(columns))) {
            throw new IllegalArgumentException();
        }
    }
    /**
     * Constructor
     * @param columns number of columns
     * @param rows number of rows
     */
    public Board(int rows, int columns) {
        Board.rows =rows;
        Board.columns =columns;

    }

    /**
     * This method returns the array with unique non-Zero integer number. The array returned by this method are used to set obstacles in the board.
     * @param size integer number that defines what should be the size of the array
     * @return array of unique integer number
     */
    public static int[] uniqueNumbers(int size) {
        int[] a = new int[size];
        for (int i = 0; i < size; i++) {
            a[i] = (int)((Math.random()*columns)+1);//note, this generates numbers from [0,9]
            for (int j = 0; j < i; j++) {
                if (a[i] == a[j]) {
                    i--; //if a[i] is a duplicate of a[j], then run the outer loop on i again
                    break;
                }
            }
        }
        return a;
    }

    /**
     * This is the essential method which will create the board with: User defined rows and columns, user defined starting lane of both player and 3 different obstacles(which will be randomly generated and set in the board).
     * @param player2 Player 2 object
     * @param player1 Player 1 object
     */
    public void playerPosition(Player player1, Player player2) {

        for (int i = rows - 1; i >= 0; i--) {

            for (int j = 0; j <= columns - 1; j++) {
                if (i == player1.getX() && j == player1.getY()) {
                    System.out.print("[P1]");
                } else if (i == player2.getX() && j == player2.getY()) {
                    System.out.print("[P2]");
                }else if (fence.checkFences(i,j)){
                    System.out.print("[FE]");
                }else if(tarpit.checkTarpit(i,j)){
                    System.out.print("[TA]");
                }else if(teleportation.checkTeleportation(i,j)){
                    System.out.print("[TP]");
                }else{
                    System.out.print("[--]");
                }
            }
            System.out.print("\n");
        }
    }


}