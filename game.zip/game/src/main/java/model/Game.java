package model;

import controller.*;

import java.util.Scanner;

import static model.Board.uniqueNumbers;

/**
 * This class is for playing the entire game.
 * <p>
 * From this class player is asked for preferred rows and columns to create the board. They are then asked
 * to enter the desire lanes where they want to play and the game start and they can move one by one until one of them
 * wins the game.
 * </p>
 * <p>
 * While playing the game they will face several obstacles like another player, TarPit, Teleportation and fences. In this
 * class there are several methods which provides different essential functionality to play the game.
 * </p>
 *
 * @author shailab
 *
 */
public class Game {
    /**
     * Number of rows.
     */
    private static int rows ;
    /**
     * Number of columns.
     */
    private static int columns;
    /**
     * Creating the instance of fence
     */
    static Fence fence = new Fence();
    /**
     * Creating the instance of TarPit
     */
    static Tarpit tarpit = new Tarpit();
    /**
     * Creating the instance of Teleportation
     */
    static Teleportation teleportation = new Teleportation();
    /**
     * player 1 object
     */
    static Player p1= new Player(3,4);
    /**
     * player 2 object
     */
    static Player p2= new Player(2,3);
    /**
     * boolean to check if players has reached last row or not
     */
    static boolean lastRow = false ;


    /**
     * This method is for asking inputs from the user to setup the game and then playing the game.
     *
     * <p>
     * This method will use the user inputs to play the game. Also In this method obstacles, player position are set up and by calling other function
     * game is played until and unless one player will win the game.
     * </p>
     * @param args argument
     */
    public static void main(String[] args) {
           int x, y;
            Board board = new Board(rows, columns);

            Scanner sc = new Scanner(System.in);
            System.out.print(" Please Enter Number of Rows(Greater then 10 is recommended) : ");
            rows = sc.nextInt();
            board.setRows(rows);

            System.out.print(" Please Enter Number of Columns(Greater then 10 is recommended) : ");
            columns = sc.nextInt();
            board.setColumns(columns);

            int[] k = uniqueNumbers((40*board.getColumns())/100);
            int[] l = uniqueNumbers((40*board.getColumns())/100);
            int[] a = uniqueNumbers((45*board.getColumns())/100);
            int[] b = uniqueNumbers((45*board.getColumns())/100);
            int[] m = uniqueNumbers((50*board.getColumns())/100);
            int[] n = uniqueNumbers((50*board.getColumns())/100);

            fence.setX(k);
            fence.setY(l);
            tarpit.setX(a);
            tarpit.setY(b);
            teleportation.setX(m);
            teleportation.setY(n);

            System.out.println("Please enter name of PLAYER 1");
            String player1st = sc.next();
            System.out.println("Please enter name of PLAYER 2");
            String player2nd = sc.next();

            System.out.println("");
            System.out.println(player1st+ " is the 1st player and will be playing as P1 & " + player2nd+ " is the 2nd player and will be playing as P2");
            System.out.println("");

            System.out.println("Choose lane for "+ player1st);
            x = sc.nextInt();
            System.out.println("Choose lane for PLAYER 2 "+ player2nd);
            y = sc.nextInt();
            p1.setX(0);
            p1.setY(x-1);
            p2.setX(0);
            p2.setY(y-1);

//            p1 = new Player(0, x - 1);
//             p2 = new Player(0, y - 1);

            System.out.println("******Initial board with the initial players position******");

            board.playerPosition(p1, p2);

        while(!lastRow) {
                if(!isWinner(p2)) {
                    p1.setPlayerName(player1st);
                    if(p1.skipTurn) {
                        System.out.println("your turn is skipped because of tarpit");
                        p1.skipTurn = false;
                    } else {

                        movePlayer(p1);

                        if (!isWinner(p1)) {
                            board.playerPosition(p1, p2);
                        } else
                            announceWinner(p1);
                    }

                }
                if(!isWinner(p1)) {
                    p2.setPlayerName(player2nd);
                    if(p2.skipTurn) {
                        System.out.println("your turn is skipped because of tarpit");
                        p2.skipTurn = false;
                    } else {
                        movePlayer(p2);
                        if (!isWinner(p2)) {
                            board.playerPosition(p1, p2);
                        } else
                            announceWinner(p2);
                    }
                }

                // was going to implement the scoreboard but couldn't finish

//                 if(isWinner(p1)|| (isWinner(p2))) {
//
//                     try {
//                         FileWriter myWriter = new FileWriter("ScoreBoard.txt");
//                         for (int i = 0; i < 2; i++) {
//                             myWriter.write(p1.getPlayerName());
//
//                             myWriter.write(p2.getPlayerName());
//                         }
//                         myWriter.close();
//                     } catch (IOException e) {
//                         System.out.println("An error occurred.");
//                         e.printStackTrace();
//                     }
//                 }

          }
    }

    /**
     *  This method is for checking if the player is winner or not
     *
     * @param player Player object who is playing the game.
     * @return True if the player is winner otherwise false
     */
    public static boolean isWinner(Player player){
            return player.getX() > rows-2;
        }

    /**
     * This method Is basically to avoid the player clashing and to treat another player as an obstacles.
     * It checks if there is another player or not when the player is moving on his way.
     *
     * @param player Player object who is playing the game.
     * @param x row position's of the player after player moves in forward or backward direction.
     * @param y column position's of the player after player moves left or right when there is obstacle ahead.
     * @return True if, position the player want to move already is the position of another player otherwise false.
     */
    public static boolean checkPlayer(Player player, int x ,int y){
        if(p1.equals(player)){
            return x == p2.getX() && y == p2.getY();
        } else {
            return x == p1.getX() && y == p1.getY();
        }
    }

    /**
     * This method is to switch the position of player's if one of them hit the teleportation obstacle.
     *
     * @param player player object who is playing the game
     * @param x row position of another player
     * @param y column position of another player
     */
    public static void checkTel(Player player, int x ,int y){
        if(p1.equals(player)){
            x = p2.getX();
            y = p2.getY();
            p2.setX(p1.getX());
            p2.setY(p1.getY());
            p1.setX(x);
            p1.setY(y);

        } else if (p2.equals(player)) {
            x = p1.getX();
            y = p1.getY();
            p1.setX(p2.getX());
            p1.setY(p2.getY());
            p2.setX(x);
            p2.setY(y);
        }
    }

    /**
     * This method is basically to move the player forward. when player rolls dice, if he gets direction forward then this method is called.
     * This method also checks if player will hit the obstacle while moving forward. If he hits the obstacles then he will be asked in which direction he wants to move inorder to avoid obstacles or if he wants to miss the turn
     * .And if he hits the obstacles like tarpit or teleportation then he will get penalty according to the obstacles.
     *
     * @param player player object who is currently playing the game
     * @param move number of moves player has got by rolling the dice
     */
    public static void moveForward(Player player, int move) {
        Scanner sc = new Scanner(System.in);
        int count = 0;
        boolean missTurn = false;
        int playerPos = player.getX();
        System.out.println("Your position was " + playerPos);
        System.out.println("You are moving "+ move + " steps in Forward direction");
        for (int i = 1; count < move; ) {
            if (!fence.checkFences(player.getX() + i, player.getY()) && !checkPlayer(player, player.getX() + i, player.getY())) {
                player.setX(player.getX() + i);
                count++;
                playerPos++;
                } else if (fence.checkFences(player.getX() + i, player.getY()) || checkPlayer(player, player.getX() + i, player.getY())) {
                    System.out.println("There is obstacles in front of you. Please choose one of the following options:");
                    System.out.println("1: Type 1 and enter if you want to move right");
                    System.out.println("2: Type 2 and enter if you want to move left");
                    System.out.println("3: Type 3 and enter if you want to miss your turn");
                    switch (sc.nextInt()) {
                        case 1:
                            if (player.getY() + 1 < columns && !fence.checkFences(player.getX(), player.getY() + 1) && !checkPlayer(player, player.getX(), player.getY() + i)) {
                                player.setY(player.getY() + 1);
                            } else if (player.getY() + 1 >= columns || fence.checkFences(player.getX(), player.getY() + 1) || checkPlayer(player, player.getX(), player.getY() + i)) {
                                System.out.println("You can't move right because you are in right last column or there is obstacle");
                                System.out.println("Please choose one of the option again");
                                System.out.println("1: Type 2 and enter if you want to move left");
                                System.out.println("2: Type 3 and enter if you want to miss your turn");
                                switch (sc.nextInt()) {
                                    case 2:
                                        player.setY(player.getY() - 1);
                                        break;
                                    case 3:
                                        missTurn = true;
                                        break;
                                    default:
                                        System.out.println("** You haven't choose option yet ( You Need to choose 2 or 3 **) **");
                                        break;
                                }
                                if (missTurn) {
                                    break;
                                }
                            }
                            break;
                        case 2:
                            if (player.getY() - 1 >= 0 && !fence.checkFences(player.getX(), player.getY() - 1) && !checkPlayer(player, player.getX(), player.getY() - i)) {
                                player.setY(player.getY() - 1);
                            } else if (player.getY() - 1 < 0 || fence.checkFences(player.getX(), player.getY() - 1) || checkPlayer(player, player.getX(), player.getY() - i)) {
                                System.out.println("You can't move left because you are in left first column or there is obstacle");
                                System.out.println("Please choose one of the option again");
                                System.out.println("1: Type 1 and enter if you want to move right");
                                System.out.println("2: Type 3 and enter if you want to miss your turn");
                                switch (sc.nextInt()) {
                                    case 2:
                                        player.setY(player.getY() + 1);
                                        break;
                                    case 3:
                                        missTurn = true;
                                        break;
                                    default:
                                        System.out.println("** You haven't choose option yet ( You Need to choose 1 or 3 **)");
                                        break;
                                }
                                if (missTurn) {
                                    break;
                                }
                            }
                            break;
                        case 3:
                            missTurn = true;
                            break;
                        default:
                            System.out.println("** You haven't choose option yet **");
                            break;
                    }
                    if (missTurn) {
                        player.setX(player.getX() - count);
                        break;
                    }
                }

            }
        playerPos(player, playerPos);

    }
    /**
     * This method is basically to move the player backward. when player rolls dice, if he gets direction backward then this method is called.
     * This method also checks if player will hit the obstacle while moving backward. If he hits the obstacles then he will be asked in which direction he wants to move inorder to avoid obstacles or if he wants to miss the turn
     * .And if he hits the obstacles like tarpit or teleportation then he will get penalty according to the obstacles.
     *
     * @param player player object who is currently playing the game
     * @param move number of moves player has got by rolling the dice
     */
    public static void moveBackward(Player player, int move){
        Scanner sc = new Scanner(System.in);
        int count=0;
        boolean missTurn=false;
        int playerPos = player.getX();
        System.out.println("Your position was " + playerPos);
        System.out.println("You are moving "+ move + " steps in Backward direction");
        for (int i = 1 ; count < move;) {
            if(!fence.checkFences(player.getX()-i, player.getY()) && !checkPlayer(player, player.getX()-i, player.getY())) {
                player.setX(player.getX() - i);
                count++;
                playerPos++;

            } else if(fence.checkFences(player.getX()-i, player.getY()) || checkPlayer(player, player.getX()-i, player.getY())) {
                System.out.println("There is obstacles where you want to go. Please choose one of the following options:");
                System.out.println("1: Type 1 and enter if you want to move right");
                System.out.println("2: Type 2 and enter if you want to move left");
                System.out.println("3: Type 3 and enter if you want to miss your turn");
                switch (sc.nextInt()) {
                    case 1:
                        if (player.getY() + 1 < columns && !fence.checkFences(player.getX(), player.getY() + 1) && !checkPlayer(player, player.getX(), player.getY() + i)) {
                            player.setY(player.getY() + 1);
                        } else if (player.getY() + 1 >= columns || fence.checkFences(player.getX(), player.getY() + 1) || checkPlayer(player, player.getX(), player.getY() + i)) {
                            System.out.println("You can't move right because you are in right last column or there is obstacle");
                            System.out.println("Please choose one of the option again");
                            System.out.println("1: Type 2 and enter if you want to move left");
                            System.out.println("2: Type 3 and enter if you want to miss your turn");
                            switch (sc.nextInt()) {
                                case 2:
                                    player.setY(player.getY() - 1);
                                    break;
                                case 3:
                                    missTurn = true;
                                    break;
                                default:
                                    System.out.println("** You haven't choose option yet ( You Need to choose 2 or 3 **) **");
                                    break;
                            }
                            if (missTurn) {
                                break;
                            }
                        }
                        break;
                    case 2:
                        if (player.getY() - 1 >= 0 && !fence.checkFences(player.getX(), player.getY() - 1) && !checkPlayer(player, player.getX(), player.getY() - i)) {
                            player.setY(player.getY() - 1);
                        } else if (player.getY() - 1 < 0 || fence.checkFences(player.getX(), player.getY() - 1) || checkPlayer(player, player.getX(), player.getY() - i)) {
                            System.out.println("You can't move left because you are in left first column or there is obstacle");
                            System.out.println("Please choose one of the option again");
                            System.out.println("1: Type 1 and enter if you want to move right");
                            System.out.println("2: Type 3 and enter if you want to miss your turn");
                            switch (sc.nextInt()) {
                                case 1:
                                    player.setY(player.getY() + 1);
                                    break;
                                case 3:
                                    missTurn = true;
                                    break;
                                default:
                                    System.out.println("** You haven't choose option yet ( You Need to choose 2 or 3 **)");
                                    break;
                            }
                            if (missTurn) {
                                break;
                            }
                        }
                        break;
                    case 3:
                        missTurn = true;
                        break;
                    default:
                        System.out.println("** You haven't choose option yet **");
                        break;
                }
            }
             if(missTurn) {
                 player.setX(player.getX()+count);
                break;
            }

        }
        playerPos(player, playerPos);
    }

    /**
     *  This method prints the current position of the player and also checks for the tarpit and teleportation obstacles.
     *
     * @param player playerObject who is playing the game
     * @param playerPos position of the current player who is playing the game
     */
    private static void playerPos(Player player, int playerPos) {
        System.out.println("Your current position is " + playerPos);

        if (tarpit.checkTarpit(player.getX() , player.getY())) {
            System.out.println("You have hit the Tarpit!! Now your next turn will be missed");
            player.skipTurn = true;
        }
        if (teleportation.checkTeleportation(player.getX(), player.getY())) {
            System.out.println("Player position switched because you hit teleportation");
            checkTel(player, player.getX(), player.getY());

        }
    }

    /**
     * This method is to move the player which calls method movePlayerForward and movePlayerBackward.
     * Here, we are rolling both dice and after knowing the move number and the direction in which player should move, he/she will move.
     * @param player player object who is playing the game
     */
    public  static void movePlayer(Player player){
               int move = Dice.moveTo();
                Scanner sc = new Scanner(System.in);
                System.out.println("Hey " + player.getPlayerName() + " hit Enter to start rolling dice ");
                sc.nextLine();
                if (Dice.direction().equals("forward")) {
                    moveForward(player, move);
                } else if (Dice.direction().equals("backward")) {
                    if (player.getX() == 0) {
                        player.setX(player.getX());
                        System.out.println("Your current position is " + player.getX());
                        System.out.println("Can't move backward cause you haven't started to played");
                    } else if (move > player.getX()) {
                        player.setX(player.getX());
                        System.out.println("Your current position is " + player.getX());
                        System.out.println("You are in " + player.getX() + " position so you cannot move backward greater than your position");
                    } else{
                            moveBackward(player, move);
                    }
                } else if (Dice.direction().equals("miss")) {
                    player.setX(player.getX());
                    System.out.println("You missed your turn");
                    System.out.println("Your current position is " + player.getX());
                } else {
                    moveForward(player, move);
                }
            System.out.println(" ");

        }

    /**
     * This method will announce winner if the playing player is winner
     * @param p player object who is playing the game.
     */
    public static  void announceWinner(Player p){
            if (isWinner(p)){
                System.out.println("*******");
                System.out.println("winner is "+ p.getPlayerName());
                System.out.println("*******");
                lastRow=true;
            }
        }
}
