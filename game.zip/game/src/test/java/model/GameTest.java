package model;

import controller.Fence;
import controller.Player;
import controller.Tarpit;
import controller.Teleportation;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GameTest {

    @Test
    void checkPlayer() {
        Player p1 = new Player(1, 3);
        Boolean t = Game.checkPlayer(p1, 2,3);
        assertEquals(t, false);

    }

    @Test
    void checkTel() {
        Player p1 = new Player(2, 1);
        Player p2 = new Player(3, 4);
        Game.checkTel(p1, 3, 4);
        assertEquals(p2.getX(),3);
        assertEquals(p2.getY(),4);
        assertEquals(p1.getX(),2);
        assertEquals(p1.getY(),1);

    }

    @Test
    void testMoveForward() {

        Player p1 = new Player(2, 2);
        int []x= {11,11};
        int []y= {11,11};
        Fence.setX(x);
        Fence.setY(y);
        Tarpit.setX(x);
        Tarpit.setY(y);
        Teleportation.setX(x);
        Teleportation.setY(y);
        Game.moveForward(p1, 2);
        assertEquals(p1.getX(), 4);

    }

    @Test
    void testMoveBackward() {

        Player p1 = new Player(4, 2);
        int []x= {10,10};
        int []y= {10,10};
        Fence.setX(x);
        Fence.setY(y);
        Tarpit.setX(x);
        Tarpit.setY(y);
        Teleportation.setX(x);
        Teleportation.setY(y);
        Game.moveBackward(p1, 2);
        assertEquals(p1.getX(), 2);

    }
}