package model;

import static org.junit.jupiter.api.Assertions.*;

import controller.Fence;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FenceTest {
    Fence fence;
    int[] x;
    int[] y;
    @BeforeEach
    void setUp() throws Exception {
        x = new int[] {1};
        y = new int[] {4};
        fence = new Fence(x,y);
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @Test
    void testFence() {
        x = new int[] {2};
        y = new int[] {2};
        fence = new Fence(x,y);
        assertEquals(fence.getX(), x);
        assertEquals(fence.getY(), y);
    }

    @Test
    void testGetX() {
        assertEquals(fence.getX(), x);
    }

    @Test
    void testSetX() {
        int[] temp = new int[] {2};
        fence.setX(temp);
        assertEquals(fence.getX(), temp);
    }



    @Test
    void testSetY() {
        int[] temp = new int[] {6};
        fence.setY(temp);
        assertEquals(fence.getY(), temp);
    }

    @Test
    void testCheckFences() {
        int[] tempX = new int[] {6};
        int[] tempY = new int[] {6};
        Fence f = new Fence(tempX,tempY);
        assertEquals(f.checkFences(6, 6),true);
    }

}