package model;

import controller.Dice;
import org.junit.jupiter.api.Test;


class DiceTest {

    @Test
    void moveTo() {
        int t= Dice.moveTo();
        if(t==1|| t==2||t==3||t==4){
            System.out.println("pass");
        }else{
            System.out.println("fail");
        }
    }

    @Test
    void direction() {
        String t= Dice.direction();
        if(t.equals("forward") || t.equals("forward2") || t.equals("backward") || t.equals("miss")){
            System.out.println("pass");
        }else{
            System.out.println("fail");
        }
    }
}