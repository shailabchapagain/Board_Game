package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BoardTest {

    Board b;

    @BeforeEach
    void setUp() throws Exception {
        b = new Board(10,10);
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @Test
    void testIsNumber() {
        Boolean t = Board.isNumber("12");
        assertEquals(t, true);
    }


    @Test
    void testGetColumns() {
        assertEquals(b.getColumns(), 10);
    }

    @Test
    void testSetColumns() {
        int col = 20;
        b.setColumns(col);
        assertEquals(b.getColumns(), 20);
    }

    @Test
    void testBoard() {
        try {
            Board board = new Board(5,5);
            assertTrue(true);
        } catch (Exception e) {
            fail("Some exception occurred");
        }
    }

    @Test
    void testUniqueNumbers() {
        int[] a = Board.uniqueNumbers(5);
        assertEquals(a.length, 5);
    }



}