package model;

import controller.Fence;
import controller.Tarpit;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TarpitTest {

    Tarpit tarpit;
    int[] x;
    int[] y;
    @BeforeEach
    void setUp() throws Exception {
        x = new int[] {1};
        y = new int[] {4};
        tarpit = new Tarpit(x,y);
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @Test
    void testFence() {
        x = new int[] {2};
        y = new int[] {2};
        tarpit = new Tarpit(x,y);
        assertEquals(tarpit.getX(), x);
        assertEquals(tarpit.getY(), y);
    }

    @Test
    void testGetX() {
        assertEquals(tarpit.getX(), x);
    }

    @Test
    void testSetX() {
        int[] temp = new int[] {2};
        tarpit.setX(temp);
        assertEquals(tarpit.getX(), temp);
    }



    @Test
    void testSetY() {
        int[] temp = new int[] {6};
        tarpit.setY(temp);
        assertEquals(tarpit.getY(), temp);
    }

    @Test
    void testCheckTarpit() {
        int[] tempX = new int[] {6};
        int[] tempY = new int[] {6};
        Tarpit f = new Tarpit(tempX,tempY);
        assertEquals(f.checkTarpit(6, 6),true);
    }
}