package model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TeleportationTest {

    @Test
    void getX() {
    }

    @Test
    void setX() {
    }

    @Test
    void getY() {
    }

    @Test
    void setY() {
    }

    @Test
    void checkTeleportation() {
    }
}