I haven't implemented game in java FX and my game runs on the command Line Terminal.

Some functionality of the game:
1: User defined board
2: User chosen starting lane
3: Randomly generated obstacles in each game(can be also used when setting the difficulty levels like easy we can have few obstacles, hard we can have many obstacles.)
4: Playable game and announcing the winner at last.

Some requirements I couldn't implement:
1: JAVA FX
2: ScoreBoard( I leave it to complete in the last moment but couldn't finish it. My Idea for it was to create a file with two columns:
   (1st columns: Names of the player)
   (2nd columns: Time taken by the player to win the game)
    with this file by comparing the time taken I was wishing to show top 10 less time taken players to win the game.


Below are the steps showing how the game is supposed to run

Steps to run the game:
1) please give valid inputs for what is asked in the command line terminal.
    (i) for rows and columns(number from 10 to as may as you want)
    (ii) give name of 2 players
    (iii) Choose lane for both players(any number from 1 to number of columns you have created)

2) Then the initial board will be shown with initial player position and randomly created obstacles.

3) Now player 1 will be playing first. So you need to hit enter then dice will be rolled, and you will move to specific position.

4) then player 2 will be asked and doing same you can play the game.

5) If any player will come near to the fence obstacles then his way will be blocked. He will be asked to move left, right or miss the turn. And by entering specific number
   and hitting enter now you can move right, left, or you can miss the turn.

6) If you went to the exact place where TarPit or Teleportation is located then following things will happen.
In case TarPit: You will miss next turn;
In case Teleportation: Position of the players will be switched.

These two obstacles cannot be avoided if you hit it.
For e.g. if one of these two obstacle is in position 2 but you are moving to 4 in forward direction you will not hit the obstacle.
Inorder to hit the obstacles you should be moving 2 in forward direction(You should reach exact position where the obstacle is inorder to hit the obstacles).

By passing through this obstacles one of the player will reach the end of the board, and he will be announced as a winner.

__________________________________________________________________________________________________________________________________________________________________________________________

HOW TO RUN TESTS FOR EACH CLASS?
All the test cases can be run one by one.
I used Intellij so Ya we can just go inside the test/model directory and can run each test file.

